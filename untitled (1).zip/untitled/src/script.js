// script.js

// Menampilkan alert saat halaman dimuat
window.addEventListener('DOMContentLoaded', () => {
  console.log("Halaman CV Trisnayun Dalending berhasil dimuat.");
});

// Fungsi interaktif sederhana (misalnya untuk menyorot tabel saat diklik)
document.addEventListener("DOMContentLoaded", function () {
  const tables = document.querySelectorAll("table");

  tables.forEach((table) => {
    table.addEventListener("click", () => {
      table.style.backgroundColor = "#e9f7ef";
    });
  });
});